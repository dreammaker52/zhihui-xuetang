import type { Subject, Question, PracticeResult, WrongQuestion, Stats, StudyRecord } from '../types'

// 开发环境由 Vite 代理到 http://localhost:3001，生产环境由后端直接托管静态文件
const API_BASE = '/api'

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`API ${path} failed: ${res.status} ${text}`)
  }
  return res.json() as Promise<T>
}

export const learningAPI = {
  // 课程
  getCourses: () => request<Subject[]>('/courses'),
  getCourse: (subjectId: string) => request<Subject>(`/courses/${subjectId}`),

  // 练习
  generateQuestions: (data: {
    subject: string
    lessonTitle: string
    knowledgePoints: string[]
    count?: number
  }) =>
    request<{ questions: Question[] }>('/practice/generate', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  submitPractice: (data: {
    subject: string
    lessonId: string
    lessonTitle: string
    questions: any[]
    answers: string[]
    knowledgePoints?: string[]
  }) =>
    request<{
      score: number
      correctCount: number
      totalQuestions: number
      results: PracticeResult[]
    }>('/practice/submit', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // 错题本
  getWrongQuestions: (subject?: string) =>
    request<{ questions: WrongQuestion[] }>(`/wrong-book${subject ? `?subject=${encodeURIComponent(subject)}` : ''}`),
  deleteWrongQuestion: (id: string) =>
    request<{ success: boolean }>(`/wrong-book/${id}`, { method: 'DELETE' }),
  explainWrongQuestion: (
    id: string,
    body: { question: string; correctAnswer: string; explanation: string; subject: string }
  ) =>
    request<{ explanation: string }>(`/wrong-book/${id}/explain`, {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  generateVariant: (id: string, body: { question: string; knowledgePoint: string; subject: string }) =>
    request<{ question: Question }>(`/wrong-book/${id}/variant`, {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  // AI答疑
  chat: (question: string, subject: string) =>
    request<{ answer: string }>('/ai/chat', {
      method: 'POST',
      body: JSON.stringify({ question, subject }),
    }),

  // 记录学习行为
  recordStudy: (data: { subject: string; lessonId: string; lessonTitle: string; action: string }) =>
    request<{ success: boolean }>('/ai/study', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // 统计
  getStats: () => request<Stats>('/stats'),
  getPracticeRecords: (limit = 20) =>
    request<{ records: any[] }>(`/stats/practices?limit=${limit}`),
  getStudyRecords: (limit = 50) =>
    request<{ records: StudyRecord[] }>(`/stats/study?limit=${limit}`),
}
